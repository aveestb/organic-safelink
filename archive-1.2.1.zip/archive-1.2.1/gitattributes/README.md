# This is just an empty file for github linguist and is not required for safelink at all.
